﻿// Copyright (c) 2025 Aukke Production - Keylance. All Rights Reserved.

#include "KeylanceSubsystem.h"
#include "LocalDataSave.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HttpModule.h"
#include "Interfaces/IHttpResponse.h"
#include "Interfaces/IHttpRequest.h"
#include "Engine/Engine.h"
#include "Misc/DateTime.h"
#include "Misc/OutputDeviceNull.h"
#include "Kismet/GameplayStatics.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

void UKeylanceSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
    Super::Initialize(Collection);
    if (bIsProtected == true)
    {
        LoadProtectionStatus();
    }
    UE_LOG(LogTemp, Warning, TEXT("Keylance Subsystem initialized."));
}

// Save the protection status to the save game
bool UKeylanceSubsystem::SaveProtectionStatus()
{
    ULocalDataSave* SaveGameInstance = Cast<ULocalDataSave>(UGameplayStatics::CreateSaveGameObject(ULocalDataSave::StaticClass()));
    if (!SaveGameInstance)
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to create Keylance save object."));
        return false;
    }

    SaveGameInstance->ExpirationDayData = LocalExpirationDay;
    SaveGameInstance->ExpirationMonthData = LocalExpirationMonth;
    SaveGameInstance->ExpirationYearData = LocalExpirationYear;
    SaveGameInstance->bIsProtectedData = bIsProtected;

    const bool bSaveSuccess = UGameplayStatics::SaveGameToSlot(SaveGameInstance, TEXT("driver_store.bin"), 0);

    UE_LOG(LogTemp, Warning, TEXT("Protection status saved: %s"), bSaveSuccess ? TEXT("true") : TEXT("false"));
    return bSaveSuccess;
}

// Load the protection status from the save game
void UKeylanceSubsystem::LoadProtectionStatus()
{
    if (UGameplayStatics::DoesSaveGameExist(TEXT("driver_store.bin"), 0))
    {
        ULocalDataSave* LoadedGame = Cast<ULocalDataSave>(UGameplayStatics::LoadGameFromSlot(TEXT("driver_store.bin"), 0));
        if (LoadedGame)
        {
            bIsProtected = LoadedGame->bIsProtectedData;
            LocalExpirationDay = LoadedGame->ExpirationDayData;
            LocalExpirationMonth = LoadedGame->ExpirationMonthData;
            LocalExpirationYear = LoadedGame->ExpirationYearData;

            UE_LOG(LogTemp, Warning, TEXT("Data loaded: %04d-%02d-%02d | Protected: %s"),
                LocalExpirationYear, LocalExpirationMonth, LocalExpirationDay,
                bIsProtected ? TEXT("true") : TEXT("false"));
        }
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("No save found."));
    }
}

void UKeylanceSubsystem::GetOsDate()
{
    FDateTime CurrentDate = FDateTime::Now();
    CurrentDay = CurrentDate.GetDay();
    CurrentMonth = CurrentDate.GetMonth();
    CurrentYear = CurrentDate.GetYear();
}

void UKeylanceSubsystem::InitProjectSettings()
{
    // Retrieve project settings
    const UExposeOnPS* Settings = GetDefault<UExposeOnPS>();
    LocalApiKey = Settings->Apikey;
    LocalProjectKey = Settings->ProjectKey;
}

void UKeylanceSubsystem::Deinitialize()
{
    Super::Deinitialize();

    // Optional cleanup here
}

void UKeylanceSubsystem::SetApiKey(FString Key, FString Id, bool& bSuccess)
{
    UExposeOnPS* Settings = GetMutableDefault<UExposeOnPS>();
    Settings->Apikey = Key;
    LocalApiKey = Settings->Apikey;
    Settings->ProjectKey = Id;
    LocalProjectKey = Settings->ProjectKey;
    UE_LOG(LogTemp, Warning, TEXT("Account info has changed."));
    bSuccess = true;
}

void UKeylanceSubsystem::CheckKey()
{
    CheckApiKeyAndExitIfInvalid();
}

// BindLambda for the HTTP request
void UKeylanceSubsystem::CheckApiKeyAndExitIfInvalid()
{
    if (!bIsProtected)
        return;

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();

    FString FullUrl = FString::Printf(TEXT("https://aukkeproduction.fr/Keylance_Api/VerifKey.php?key=%s&project=%s"), *LocalApiKey, *LocalProjectKey);

    Request->SetURL(FullUrl);
    Request->SetVerb("GET");
    Request->SetHeader("Content-Type", "application/json");

    TWeakObjectPtr<UKeylanceSubsystem> WeakThis(this);

    Request->OnProcessRequestComplete().BindLambda(
        [WeakThis](FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
        {
            if (!WeakThis.IsValid()) return;

            if (bWasSuccessful && Response.IsValid())
            {
                FString ResponseBody = Response->GetContentAsString();

                TSharedPtr<FJsonObject> JsonObject;
                TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ResponseBody);

                if (FJsonSerializer::Deserialize(Reader, JsonObject) && JsonObject.IsValid())
                {
                    if (!JsonObject->GetBoolField(TEXT("success")))
                    {
                        UE_LOG(LogTemp, Error, TEXT("Invalid key or invalid project ID."));
                        WeakThis->ApiMessage = ("Invalid key or invalid project ID.");
                        WeakThis->OnRequestFailed.Broadcast();
                        return;
                    }

                    // Protection check
                    bool bJsonIsProtected = JsonObject->GetBoolField(TEXT("is_protected"));
                    if (!bJsonIsProtected)
                    {
                        UE_LOG(LogTemp, Warning, TEXT("Authorized access with protection disabled."));
                        WeakThis->ApiMessage = ("Authorized access with protection disabled.");
                        WeakThis->OnProjectUnprotected.Broadcast();
                        WeakThis->bIsProtected = false;
                        WeakThis->SaveProtectionStatus();
                        return;
                    }

                    // Activation check
                    bool bIsActive = JsonObject->GetBoolField(TEXT("active"));
                    if (!bIsActive)
                    {
                        UE_LOG(LogTemp, Error, TEXT("Invalid key. Access denied."));
                        WeakThis->ApiMessage = ("Invalid key. Access denied.");
                        WeakThis->OnRequestFailed.Broadcast();
                        return;
                    }

                    // Expiration date
                    FString ExpirationDateStr = JsonObject->GetStringField(TEXT("expiration_date"));
                    FDateTime ExpirationDate;
                    if (FDateTime::ParseIso8601(*ExpirationDateStr, ExpirationDate))
                    {
                        WeakThis->LocalExpirationDay = ExpirationDate.GetDay();
                        WeakThis->LocalExpirationMonth = ExpirationDate.GetMonth();
                        WeakThis->LocalExpirationYear = ExpirationDate.GetYear();
                        WeakThis->SaveProtectionStatus();
                        UE_LOG(LogTemp, Warning, TEXT("Expiration date updated: %s"), *ExpirationDateStr);
                    }
                    else
                    {
                        UE_LOG(LogTemp, Error, TEXT("Date parsing error: %s"), *ExpirationDateStr);
                    }

                    WeakThis->OnRequestSuccess.Broadcast();
                    UE_LOG(LogTemp, Warning, TEXT("Valid key, active project, and protected."));
                    WeakThis->ApiMessage = ("Invalid key.");
                    return;
                }
                else
                {
                    UE_LOG(LogTemp, Error, TEXT("JSON parsing error."));
                    UE_LOG(LogTemp, Warning, TEXT("Raw response: %s"), *Response->GetContentAsString());
                }
            }
            else
            {
                // Fallback if no server response
                UE_LOG(LogTemp, Error, TEXT("HTTP request failed. Fallback on local date."));

                FDateTime CurrentDate = FDateTime::Now();
                FDateTime ExpirationDate(WeakThis->LocalExpirationYear, WeakThis->LocalExpirationMonth, WeakThis->LocalExpirationDay);

                if (CurrentDate < ExpirationDate)
                {
                    WeakThis->OnRequestSuccess.Broadcast();
                    UE_LOG(LogTemp, Warning, TEXT("Expiration date not reached."));
                    WeakThis->ApiMessage = ("The expiration date is still valid.");
                }
                else
                {
                    WeakThis->OnRequestFailed.Broadcast();
                    UE_LOG(LogTemp, Error, TEXT("Access denied: expiration date reached."));
                    WeakThis->ApiMessage = ("The expiration date has expired.");
                }
            }
        }
    );

    Request->ProcessRequest();
}
