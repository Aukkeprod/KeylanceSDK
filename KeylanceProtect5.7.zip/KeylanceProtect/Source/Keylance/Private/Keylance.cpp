// Copyright (c) 2025 Aukke Production - Keylance. All Rights Reserved.
// Copyright Epic Games, Inc. All Rights Reserved.

#include "Keylance.h"

#define LOCTEXT_NAMESPACE "FKeylanceProjectModule"

void FKeylanceModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module


}

void FKeylanceModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FKeylanceModule, Keylance)