// Copyright (c) 2025 Aukke Production - Keylance. All Rights Reserved.


#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "KeylanceSubsystem.h"
#include "KeylanceBlueprintLibrary.generated.h"



UCLASS()
class KEYLANCE_API UKeylanceBlueprintLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Keylance", meta = (WorldContext = "WorldContextObject"))
    static void SetAccountInfo(UObject* WorldContextObject, FString NewApiKey, FString NewId, bool& bSuccess);

    UFUNCTION(BlueprintCallable, Category = "Keylance", meta = (WorldContext = "WorldContextObject"))
    static UKeylanceSubsystem* GetProtectSubsystem(UObject* WorldContextObject);

    UFUNCTION(BlueprintCallable, Category = "Keylance", meta = (WorldContext = "WorldContextObject"))
    static void CheckKey(UObject* WorldContextObject);


};


