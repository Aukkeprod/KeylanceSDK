// Copyright (c) 2025 Aukke Production - Keylance. All Rights Reserved.
// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "ExposeOnPS.generated.h"

UCLASS(Config = Game, DefaultConfig)
class KEYLANCE_API UExposeOnPS : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UPROPERTY(Category = "Keylance", Config, EditAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = true))
	FString Apikey = "Your api key";

	UPROPERTY(Category = "Keylance", Config, EditAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = true))
	FString ProjectKey = "Your project Id";

};
