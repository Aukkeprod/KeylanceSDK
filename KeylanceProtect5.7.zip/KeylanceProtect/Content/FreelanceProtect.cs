using UnrealBuildTool;

public class FreelanceProtect : ModuleRules
{
    public FreelanceProtect(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(new string[] {
            "Core",
            "CoreUObject",
            "Engine",
            "InputCore",
            "Http", // Ajout du module Http
            "Json", // Ajout du module Json pour la s�rialisation
            "JsonUtilities" // Si vous utilisez JsonUtilities
        });

        PrivateDependencyModuleNames.AddRange(new string[] {
            // Ajoutez ici d'autres modules si n�cessaire
        });

        // Si vous utilisez Slate ou SlateCore
        // PrivateDependencyModuleNames.AddRange(new string[] { "Slate", "SlateCore" });
    }
}
