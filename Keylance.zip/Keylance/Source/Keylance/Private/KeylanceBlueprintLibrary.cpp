// Copyright (c) 2025 Aukke Production - Keylance. All Rights Reserved.



#include "KeylanceBlueprintLibrary.h"
#include "KeylanceSubsystem.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Misc/DateTime.h"

void UKeylanceBlueprintLibrary::SetAccountInfo(UObject* WorldContextObject, FString NewApiKey, FString NewId, bool& bSuccess)
{
    bSuccess = false;

    if (!WorldContextObject)
    {
        UE_LOG(LogTemp, Warning, TEXT("SetAccountInfo: WorldContextObject is null"));
        return;
    }

    UWorld* World = GEngine->GetWorldFromContextObjectChecked(WorldContextObject);
    if (!World || !World->IsGameWorld())
    {
        UE_LOG(LogTemp, Warning, TEXT("SetAccountInfo: World is not valid or not a game world"));
        return;
    }

    UKeylanceSubsystem* Subsystem = World->GetSubsystem<UKeylanceSubsystem>();
    if (!Subsystem)
    {
        UE_LOG(LogTemp, Warning, TEXT("SetAccountInfo: Subsystem not found"));
        return;
    }

    Subsystem->SetApiKey(NewApiKey, NewId, bSuccess);
}

UKeylanceSubsystem* UKeylanceBlueprintLibrary::GetProtectSubsystem(UObject* WorldContextObject)
{
    if (!WorldContextObject)
    {
        UE_LOG(LogTemp, Warning, TEXT("GetProtectSubsystem: WorldContextObject is null"));
        return nullptr;
    }

    UWorld* World = GEngine->GetWorldFromContextObjectChecked(WorldContextObject);
    if (!World)
    {
        UE_LOG(LogTemp, Warning, TEXT("GetProtectSubsystem: World is null"));
        return nullptr;
    }

    UE_LOG(LogTemp, Log, TEXT("GetProtectSubsystem: Using world %s"), *World->GetName());
    return World->GetSubsystem<UKeylanceSubsystem>();
}

void UKeylanceBlueprintLibrary::CheckKey(UObject* WorldContextObject)
{
    if (!WorldContextObject)
    {
        UE_LOG(LogTemp, Warning, TEXT("CheckKey: WorldContextObject is null"));
        return;
    }

    UWorld* World = GEngine->GetWorldFromContextObjectChecked(WorldContextObject);
    if (!World || !World->IsGameWorld())
    {
        UE_LOG(LogTemp, Warning, TEXT("CheckKey: World is not valid or not a game world"));
        return;
    }

    UKeylanceSubsystem* Subsystem = World->GetSubsystem<UKeylanceSubsystem>();
    if (!Subsystem)
    {
        UE_LOG(LogTemp, Warning, TEXT("CheckKey: Subsystem not found"));
        return;
    }

    Subsystem->CheckKey();
}