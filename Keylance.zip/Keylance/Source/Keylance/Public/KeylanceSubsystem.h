// Copyright (c) 2025 Aukke Production - Keylance. All Rights Reserved.

#pragma once
#include "Kismet/GameplayStatics.h"
#include "CoreMinimal.h"
#include "Engine/EngineTypes.h"
#include "Engine/World.h"
#include "Delegates/Delegate.h"
#include "LocalDataSave.h"
#include "ExposeOnPS.h"
#include "HttpModule.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "UObject/ObjectMacros.h"
#include "UObject/ScriptMacros.h"
#include "Keylance.h"
#include "Misc/DateTime.h"
#include "Misc/OutputDeviceNull.h"
#include "Subsystems/WorldSubsystem.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"


#include "KeylanceSubsystem.generated.h"



// Delegate dynamique pour Blueprint
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnRequestFailed);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnRequestSuccess);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnRequestCheatDetected);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnProjectUnprotected);


UCLASS()
class UKeylanceSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()
public:
	//Delegate dynamique for Blueprint --> This delegate will be called when the request is completed




	UPROPERTY()
	FOnRequestCheatDetected OnRequestCheatDetected;

	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "KeylanceSubsystem")
	FOnRequestFailed OnRequestFailed;

	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "KeylanceSubsystem")
	FOnRequestSuccess OnRequestSuccess;

	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "KeylanceSubsystem")
	FOnProjectUnprotected OnProjectUnprotected;

	FString SaveSlotName = TEXT("MyPluginSaveSlot");
	
	// Begin subsystem
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	// End Subsystem

	UFUNCTION()
	void LoadProtectionStatus();

	UFUNCTION()
	bool SaveProtectionStatus();


	// SDK Function
	UFUNCTION()
	void SetApiKey(const FString NewApiKey, const FString NewProjectKey, bool& bSuccess);


	UFUNCTION()
	void CheckKey();

	UFUNCTION(BlueprintCallable, Category = "KeylanceSubsystem")
	bool IsProtected() const { return bIsProtected; }


	UPROPERTY(BlueprintReadOnly, Category = "KeylanceSubsystem") //internal
	bool bIsProtected = true;

	UFUNCTION(Category = "KeylanceSubsystem")
	void InitProjectSettings();
	
	UFUNCTION(Category = "KeylanceSubsystem")
	void GetOsDate();


	UPROPERTY(BlueprintReadOnly, Category = "KeylanceSubsystem")
	FString ApiMessage = ("Nothing");


private:
	
	// Functions
	void CheckApiKeyAndExitIfInvalid();
	void SaveDate();
	FDateTime GetSavedDate();



	FString LocalApiKey;
	FString LocalProjectKey;
	int32 LocalExpirationDay;
	int32 LocalExpirationMonth;
	int32 LocalExpirationYear;

	int32 CurrentDay = 0;
	int32 CurrentMonth = 0;
	int32 CurrentYear = 0;
};
