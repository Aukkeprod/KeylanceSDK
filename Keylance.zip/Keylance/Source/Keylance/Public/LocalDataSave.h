// Copyright (c) 2025 Aukke Production - Keylance. All Rights Reserved.
// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"

#include "LocalDataSave.generated.h"

/**
 * 
 */
UCLASS()
class KEYLANCE_API ULocalDataSave : public USaveGame
{
	GENERATED_BODY()
	
public:
    UPROPERTY()
    int32 ExpirationDayData;

    UPROPERTY()
    int32 ExpirationMonthData;

    UPROPERTY()
    int32 ExpirationYearData;

    UPROPERTY()
    bool bIsProtectedData;
};